function navbar(){

    let element = document.getElementById("navbarNav");
    element.classList.toggle("navbar__nav--active");

}