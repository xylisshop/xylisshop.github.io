$('.faq__card').click(function() {
    $(this).parent().find('.faq__card__content').slideToggle()
});